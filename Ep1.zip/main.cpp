
void menu();

int main(){
    menu();
    return 0;
}